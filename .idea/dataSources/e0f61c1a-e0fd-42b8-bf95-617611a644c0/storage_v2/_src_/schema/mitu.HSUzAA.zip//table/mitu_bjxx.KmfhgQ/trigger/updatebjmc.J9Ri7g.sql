create trigger updatebjmc
  after UPDATE
  on mitu_bjxx
  for each row
  BEGIN

      IF OLD.bjmc<>NEW.bjmc THEN

      update mitu_jxrw set bjmc=NEW.bjmc  where ssbj=OLD.bjdm; 

      update mitu_cdsyb set sybmmc=NEW.bjmc  where sybmdm=OLD.bjdm; 

      update mitu_lqxsxx set ssbjmc=NEW.bjmc  where ssbj=OLD.bjdm; 

      update mitu_xsxx set ssbjmc=NEW.bjmc  where ssbj=OLD.bjdm; 

      update mitu_skjhb set skbjmc=NEW.bjmc  where skbj=OLD.bjdm; 

      END IF;

    END;

